Data
03/06/2017

A Bayesian geostatistical approach to modelling     
global distributions of *Lygodium microphyllum*     
under projected climate warming     
==================================================
     
Authors:   
John M. Humphreys (jmh09r@my.fsu.edu)    
James B. Elsner   
Thomas H. Jagger  
Stephanie Pau   
     
    
An executed version of this script can be viewed here:    
http://rpubs.com/JMHumphreys/LygPA020217     

�InvCohortSpp.csv�
Comma Separated Value
Names and Locations of Invasive Species


�LygMicro.csv�
Comma Separated Value
Names and Locations of Lygodium microphyllum occurrences

